const canvas = document.getElementById('tetris');
const context = canvas.getContext('2d');
const nextCanvas = document.getElementById('next-piece');
const nextContext = nextCanvas.getContext('2d');

const startScreen = document.getElementById('start-screen');
const gameOverScreen = document.getElementById('game-over-screen');
const finalScoreSpan = document.getElementById('final-score');
const initialsInput = document.getElementById('player-initials');
const highScoresList = document.getElementById('high-scores-list');

context.scale(20, 20);
nextContext.scale(20, 20);

let animationId = null;
let dropCounter = 0;
let dropInterval = 1000;
let lastTime = 0;

const SPEED_THRESHOLDS = [50, 200, 370];
const SPEED_INTERVALS = [800, 600, 400];

const arena = createMatrix(12, 20);
const pieces = 'ILJOTSZ';

const player = {
    pos: {x: 0, y: 0},
    matrix: null,
    score: 0,
};

let playerNextPiece = null;

function startGame() {
    startScreen.classList.add('hidden');
    gameOverScreen.classList.add('hidden');

    arena.forEach(row => row.fill(0));
    player.score = 0;
    playerNextPiece = null;

    dropInterval = 1000;

    playerReset();
    updateScore();

    if (animationId) cancelAnimationFrame(animationId);
    update();
}
window.startGame = startGame;

function gameOver() {
    cancelAnimationFrame(animationId);
    finalScoreSpan.innerText = player.score;
    initialsInput.value = '';
    gameOverScreen.classList.remove('hidden');
}

function playerReset() {
    if (!playerNextPiece) {
        player.matrix = createPiece(pieces[pieces.length * Math.random() | 0]);
        playerNextPiece = createPiece(pieces[pieces.length * Math.random() | 0]);
    } else {
        player.matrix = playerNextPiece;
        playerNextPiece = createPiece(pieces[pieces.length * Math.random() | 0]);
    }

    player.pos.y = 0;
    player.pos.x = (arena[0].length / 2 | 0) - (player.matrix[0].length / 2 | 0);

    drawNextPiece();

    if (collide(arena, player)) {
        gameOver();
    }
}

function playerDrop() {
    player.pos.y++;
    if (collide(arena, player)) {
        player.pos.y--;
        merge(arena, player);
        playerReset();
        arenaSweep();
        updateScore();
    }
    dropCounter = 0;
}

function checkSpeedIncrease(oldScore, newScore) {
    for (let i = 0; i < SPEED_THRESHOLDS.length; i++) {
        const threshold = SPEED_THRESHOLDS[i];
        const newInterval = SPEED_INTERVALS[i];

        if (oldScore < threshold && newScore >= threshold) {
            dropInterval = newInterval;
            console.log(`Livello raggiunto! Nuova velocità: ${dropInterval}ms`);
        }
    }
}

function arenaSweep() {
    let rowCount = 1;
    let oldScore = player.score;

    outer: for (let y = arena.length - 1; y > 0; --y) {
        for (let x = 0; x < arena[y].length; ++x) {
            if (arena[y][x] === 0) {
                continue outer;
            }
        }
        const row = arena.splice(y, 1)[0].fill(0);
        arena.unshift(row);
        ++y;
        player.score += rowCount * 10;
        rowCount *= 2;
    }

    checkSpeedIncrease(oldScore, player.score);
}

async function getHighScores() {
    try {
        const url = `http://127.0.0.1:8090/api/collections/scores/records`;
        const response = await fetch(url);

        if (!response.ok) { throw new Error(`Errore HTTP! Stato: ${response.status}`); }

        const data = await response.json();
        return data.items.map(item => ({ name: item.initials, score: item.score }));
    } catch (error) {
        console.error("Errore nel recupero della classifica da PocketBase:", error);
        return [];
    }
}

async function showHighScores() {
    const scores = await getHighScores();

    const sortedScores = scores.sort((a, b) => b.score - a.score);

    const topScores = sortedScores.slice(0, 5);

    highScoresList.innerHTML = topScores
        .map(score => `<li><span>${score.name}</span> <span>${score.score}</span></li>`)
        .join('');
}
window.showHighScores = showHighScores;

async function saveScore() {
    const initials = initialsInput.value.toUpperCase().trim();
    const score = player.score;

    if (initials.length !== 3) {
        alert("Inserisci esattamente 3 lettere!");
        return;
    }

    const payload = { "initials": initials, "score": score };

    try {
        const response = await fetch(`http://127.0.0.1:8090/api/collections/scores/records`, {
            method: "POST",
            body: JSON.stringify(payload),
            headers: { "Content-type": "application/json" }
        });

        if (!response.ok) { throw new Error(`Errore HTTP! Stato: ${response.status}`); }
        console.log("Punteggio inviato con successo!");

    } catch (error) {
        console.error("Errore durante il salvataggio del punteggio:", error);
        alert("Errore nel salvataggio del punteggio. Controlla la console.");
    }

    gameOverScreen.classList.add('hidden');
    startScreen.classList.remove('hidden');
    showHighScores();
}
window.saveScore = saveScore;

function drawNextPiece() {
    nextContext.fillStyle = '#111';
    nextContext.fillRect(0, 0, nextContext.canvas.width, nextContext.canvas.height);

    if (!playerNextPiece) return;

    const pieceMatrix = playerNextPiece;
    const pieceSize = pieceMatrix.length;
    let offsetX = (4 - pieceSize) / 2;
    let offsetY = (4 - pieceSize) / 2;

    if (pieceSize === 4) { offsetX = 0; offsetY = 0.5; }
    else if (pieceSize === 2) { offsetX = 1; offsetY = 1; }

    drawMatrix(pieceMatrix, {x: offsetX, y: offsetY}, nextContext);
}

function drawMatrix(matrix, offset, ctx = context) {
    const colors = [null,'#FF0D72','#0DC2FF','#0DFF72','#F538FF','#FF8E0D','#FFE138','#3877FF'];
    matrix.forEach((row, y) => {
        row.forEach((value, x) => {
            if (value !== 0) {
                ctx.fillStyle = colors[value];
                ctx.fillRect(x + offset.x, y + offset.y, 1, 1);
            }
        });
    });
}

function draw() {
    context.fillStyle = '#000';
    context.fillRect(0, 0, canvas.width, canvas.height);

    drawMatrix(arena, {x: 0, y: 0});
    drawMatrix(player.matrix, player.pos);
}

function createMatrix(w, h) {
    const matrix = [];
    while (h--) { matrix.push(new Array(w).fill(0)); }
    return matrix;
}
function createPiece(type) {
    if (type === 'I') { return [[0, 1, 0, 0],[0, 1, 0, 0],[0, 1, 0, 0],[0, 1, 0, 0]]; }
    else if (type === 'L') { return [[0, 2, 0],[0, 2, 0],[0, 2, 2]]; }
    else if (type === 'J') { return [[0, 3, 0],[0, 3, 0],[3, 3, 0]]; }
    else if (type === 'O') { return [[4, 4],[4, 4]]; }
    else if (type === 'Z') { return [[5, 5, 0],[0, 5, 5],[0, 0, 0]]; }
    else if (type === 'S') { return [[0, 6, 6],[6, 6, 0],[0, 0, 0]]; }
    else if (type === 'T') { return [[0, 7, 0],[7, 7, 7],[0, 0, 0]]; }
}
function merge(arena, player) {
    player.matrix.forEach((row, y) => {
        row.forEach((value, x) => {
            if (value !== 0) { arena[y + player.pos.y][x + player.pos.x] = value; }
        });
    });
}
function rotate(matrix, dir) {
    for (let y = 0; y < matrix.length; ++y) {
        for (let x = 0; x < y; ++x) {
            [matrix[x][y], matrix[y][x]] = [matrix[y][x], matrix[x][y]];
        }
    }
    if (dir > 0) matrix.forEach(row => row.reverse());
    else matrix.reverse();
}
function playerMove(offset) {
    player.pos.x += offset;
    if (collide(arena, player)) { player.pos.x -= offset; }
}
function playerRotate(dir) {
    const pos = player.pos.x;
    let offset = 1;
    rotate(player.matrix, dir);
    while (collide(arena, player)) {
        player.pos.x += offset;
        offset = -(offset + (offset > 0 ? 1 : -1));
        if (offset > player.matrix[0].length) {
            rotate(player.matrix, -dir);
            player.pos.x = pos;
            return;
        }
    }
}
function collide(arena, player) {
    const m = player.matrix;
    const o = player.pos;
    for (let y = 0; y < m.length; ++y) {
        for (let x = 0; x < m[y].length; ++x) {
            if (m[y][x] !== 0 &&
               (arena[y + o.y] &&
                arena[y + o.y][x + o.x]) !== 0) {
                return true;
            }
        }
    }
    return false;
}
function updateScore() {
    document.getElementById('score').innerText = "Punteggio: " + player.score;
}

function update(time = 0) {
    const deltaTime = time - lastTime;
    lastTime = time;

    dropCounter += deltaTime;
    if (dropCounter > dropInterval) {
        playerDrop();
    }
    draw();
    animationId = requestAnimationFrame(update);
}

document.addEventListener('keydown', event => {
    if (!startScreen.classList.contains('hidden') || !gameOverScreen.classList.contains('hidden')) {
        return;
    }
    if (event.key === 'ArrowLeft') {
        playerMove(-1);
    } else if (event.key === 'ArrowRight') {
        playerMove(1);
    } else if (event.key === 'ArrowDown') {
        playerDrop();
    } else if (event.key === 'ArrowUp') {
        playerRotate(1);
    }
});

showHighScores();
context.fillStyle = '#000';
context.fillRect(0, 0, canvas.width, canvas.height);